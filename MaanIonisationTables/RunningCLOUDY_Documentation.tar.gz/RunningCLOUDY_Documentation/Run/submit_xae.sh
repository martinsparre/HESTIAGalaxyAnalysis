#!/bin/bash
#PBS -q small
#PBS -r n
#PBS -l nodes=8:ppn=3
#PBS -l walltime=8:00:00
##PBS -u sparre
#PBS -m abe
#PBS -N xae
 
source /opt/env/intel-2017.sh

cd=$PBS_O_WORKDIR
nodefile="$PBS_O_WORKDIR/mynodes-"${PBS_JOBID}".txt"

cat $PBS_NODEFILE | sort | uniq >$nodefile
echo nodefile
cat $nodefile
echo
echo jobscript
cat $PBS_O_WORKDIR/xae

cat $PBS_O_WORKDIR/xae | /usr/local/bin/parallel -P 5 --sshloginfile $nodefile --workdir $PBS_O_WORKDIR --joblog $PBS_O_WORKDIR/parallel-${PBS_JOBID}.log
