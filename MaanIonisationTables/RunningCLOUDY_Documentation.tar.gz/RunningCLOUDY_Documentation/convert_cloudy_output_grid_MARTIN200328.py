'''
read cloudy ionization table output and plot ionbal vs grid axis
'''

# import libraries
print('importing libraries')
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib 
import glob
import re
import itertools
import h5py
from params import *


# -------------------------------------------------------------------
#
##
###  Defining functions

nions   = 17  # max number of ions on one line from cloudy
species_list = ['Hydrogen' ,
                'Carbon'   ,
                'Oxygen'   ,
                'Magnesium',
                'Silicon'  ,
                'Iron'     ]
ion_dict     = {'Hydrogen' : [0]      ,
                'Carbon'   : [3]      ,
                'Oxygen'   : [0, 5, 6,7],
                'Magnesium': [1]      ,
                'Silicon'  : [1, 2, 3],
                'Iron'     : [1]      }
species_dict = {'Hydrogen' : 'H'  ,
                'Carbon'   : 'C'  ,
                'Oxygen'   : 'O'  ,
                'Magnesium': 'Mg' ,
                'Silicon'  : 'Si' ,
                'Iron'     : 'Fe' }

# function to read ionization tables
def handle_single_line(splitline):
    ii = 0
    while ii < np.size(splitline):
        s = splitline[ii]
        try:
            s=float(s)
        except ValueError:
            #Cloudy elements are <= 0, so we can split on -.
            tmp = s.split("-")
            try:
                splitline[ii] = -1*float(tmp[-1])
                #Insert elements backwards: First element is ignored because it will be ""
                for q in range(-2,-np.size(tmp),-1):
                    splitline.insert(ii, -1*float(tmp[q]))
                    ii+=1
            except ValueError:
                pass
        ii+=1
    return splitline

def read_table(ion_table):
    #Species names to search the cloudy table for
    #species = ("Hydrogen", "Helium", "Carbon", "Nitrogen",
    #           "Oxygen", "Neon", "Magnesium", "Silicon", "Iron")
    species = species_list
    #
    num_table = -30*np.ones([Ntemp, Nzmet, np.size(species), nions])

    # add check if file is empty
    f=open(ion_table)
    if len(f.read()) <= 30: return num_table * np.nan
    #
    f=open(ion_table)
    # read header comment
    line = f.readline()
    # loop over grid cells and read species
    itemp = 0
    while itemp < Ntemp:
        izmet = 0
        while izmet < Nzmet:
            # read empty line, and get to Hydrogen
            line = f.readline()
            line = f.readline()
            elmt = 0
            while line != "" and elmt < len(species_list):
                #This line contains a species we want
                if re.search(species[elmt],line):
                    #Split with whitespace
                    splitline=line.split()
                    #Remove name column
                    if splitline[0] == species[elmt]:
                        splitline = splitline[1:]
                    else:
                        splitline[0] = re.sub(species[elmt], "", splitline[0])
                    splitline = handle_single_line(splitline)
                    #Ignore H2 formation
                    if species[elmt] == "Hydrogen":
                        num_table[itemp, izmet, elmt,0:2] = np.array(splitline)[:2]
                    #Set table
                    else:
                        num_table[itemp, izmet, elmt, 0:np.size(splitline)] = np.array(splitline)
                    elmt+=1
                line = f.readline()
            # continue reading until next grid cell
            while '############' not in line:
                line = f.readline()
            # setup for next grid cell
            izmet += 1
        # next grid cell
        itemp += 1
    return num_table

# -------------------------------------------------------------------
#
##
### Reading ionization tables

ion_dir     = './Run/'

# define grid nodes
print('defining grid nodes')
hden = np.linspace(hden_min, hden_max, num=Nhden, endpoint=True)
temp = np.linspace(temp_min, temp_max, num=Ntemp, endpoint=True)
zmet = np.linspace(zmet_min, zmet_max, num=Nzmet, endpoint=True)
zred = np.linspace(zred_min, zred_max, num=Nzred, endpoint=True)
Jagn = np.linspace(Jagn_min, Jagn_max, num=NJagn, endpoint=True)

# -- add no AGN --> Jagn = 0.
NJagn += 1
Jagn = np.insert(Jagn, 0, -100)

# define ionbal array
nspecies = len(species_list)
ionbal = -30.0 * np.ones([Nhden, Ntemp, Nzmet, Nzred, NJagn, nspecies, nions])

# read ionization balance data
for ihden, log_nH in enumerate(hden):
    for izred, redshift in enumerate(zred):
        for iJagn, log_Jagn in enumerate(Jagn):
            table = "{0}ionization_grid_{1}_{2}_{3}.dat".format(ion_dir, log_nH, redshift, log_Jagn)
            print('reading {}'.format(table))
            ionbal[ihden, :, :, izred, iJagn, :, :] = read_table(table)


# -------------------------------------------------------------------
#
##
### output ionization table
print('writing hdf5 tables')
data_arr = [hden  , temp  , zmet  , zred      ,     Jagn ,  ionbal ]
data_name= ['logd', 'logt', 'logZ', 'redshift', 'logJagn', 'ionbal']

for elmnt in species_list:
    for ion in ion_dict[elmnt]:
        fname = 'Martin200328_{}{}.hdf5'.format(species_dict[elmnt].lower(),ion+1)
        print('writing {}'.format(fname))
        with h5py.File(fname, 'w') as hf:
            for idata in range(len(data_name)):
                dname = data_name[idata]
                if dname == 'ionbal':
                    ielmnt = np.asscalar(np.where(np.array(species_list)   == elmnt)[0])
                    hf.create_dataset(dname, data=ionbal[:,:,:,:,:, ielmnt, ion])
                else:
                    hf.create_dataset(dname, data=data_arr[idata])


# -------------------------------------------------------------------
#
##
### Fin

print('Finitto...')
