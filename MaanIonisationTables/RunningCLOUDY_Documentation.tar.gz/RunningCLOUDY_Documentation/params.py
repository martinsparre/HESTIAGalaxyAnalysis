'''
defining common parameters for scripts in this directory
'''
"""
#
##
### begin coarse grid for testing only

# grid size
Nhden = 11   # delta_hden = 1.
Ntemp = 9    # delta_T    = 1. 
Nzmet = 6    # delta_zmet = 1.
Nzred = 5    # delta_zred = 0.25
NJagn = 11   # delta_Jagn = 1.

# grid extent
hden_min, hden_max = [-8. , 2. ]
temp_min, temp_max = [ 1. , 9. ]
zmet_min, zmet_max = [-4. , 1. ]
zred_min, zred_max = [ 0. , 1.0]
Jagn_min, Jagn_max = [-5. , 5. ]

### end testing
##
#
"""


# grid size
Nhden = 41   # delta_hden = 0.25
Ntemp = 81   # delta_T    = 0.1  
Nzmet = 6    # delta_zmet = 1.0
Nzred = 22   # delta_zred = 0.05
NJagn = 11   # delta_Jagn = 1.0

# grid extent
hden_min, hden_max = [-8. , 2.  ]
temp_min, temp_max = [ 1. , 9.  ]
zmet_min, zmet_max = [-4. , 1.  ]
zred_min, zred_max = [ 0. , 1.05]
Jagn_min, Jagn_max = [-5. , 5.  ]


# self shielding threshold
log_nH_shield_thresh = -3.0


# constants
h_planck    = 6.62607004E-34  # J.s
ryd_to_J    = 2.1798741E-18   # J/ryd
