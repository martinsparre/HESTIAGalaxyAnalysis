'''
script to resample cloudy's AGN continuum
'''


# import libraries
import numpy as np

# input
infile = './raw_agn_continuum_0.0.dat'
nu_in, Jnu_in = np.loadtxt(infile, usecols=(0,1), unpack=True)

# sort input (cloudy wraps its output)
index_sort = np.argsort(nu_in)
nu_in  =  nu_in[index_sort]
Jnu_in = Jnu_in[index_sort]

# resample agn continuum by factor fsample
fsample = 10
nu  =  nu_in[::fsample]
Jnu = Jnu_in[::fsample]

# output
output = np.zeros(nu.size, dtype=[('nu', float), ('Jnu', float)])
output['nu']  = nu
output['Jnu'] = Jnu
outfile = './AGN_continuum_0.0.dat'
header='  [nu , 4*pi*nu*Jnu]  (same as cloudy\'s save continuum output)'
np.savetxt(outfile, output, delimiter='\t', header=header)
           
