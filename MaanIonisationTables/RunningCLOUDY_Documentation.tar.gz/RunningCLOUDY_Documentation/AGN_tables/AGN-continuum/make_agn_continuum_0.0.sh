# script to run cloudy & resample it's continuum

# -- run cloudy
echo "Running Cloudy"
cloudy make_agn_continuum_0.0

# resample AGN continuum
echo "Resampling AGN continuum"
python resample_agn_continuum_0.0.py
